/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gaji_karyawan_dian;

import java.util.Scanner;

/**
 *
 * @author DNS
 */
public class Gaji_Karyawan_Dian {
    
    static void cabang(Long gaji){
        
        if(gaji>=15000000){
            System.out.println("Anda adalah Direktur");
        }
        else if(gaji >=13000000){
            System.out.println("Anda adalah Manager");
        }
        else if(gaji >=9000000){
            System.out.println("Anda adalah Kepala Bagian");
        }
        else if(gaji <8000000){
            System.out.println("Anda adalah Karyawan Produksi");
        }
        
    }
    
    public static void main(String[] args) {
        
        Scanner maji = new Scanner(System.in);
        
        Long gaji;
        
        System.out.println("Masukan Gaji anda tanpa menggunakan titik!");
        
        gaji = maji.nextLong();
        
        cabang(gaji);
        //PAKAI STR_REPLACE
        
         
        
        
    }
}
